package ai.wit.sdk;

/**
 * Created by aric on 9/15/14.
 */
public interface IWitCoordinator {
    public void stopListening();
    public void voiceActivityStarted();
}
